A simple Shiny app that displays eruption data for the Google Trend Index app.
