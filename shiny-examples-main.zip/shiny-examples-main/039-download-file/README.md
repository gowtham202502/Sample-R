To create file download button, there should be a `downloadButton` on the client side, and a corresponding `downloadHandler` on the server side.
